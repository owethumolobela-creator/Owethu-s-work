<?php
declare(strict_types=1);
require_once 'Database.php';

$message = '';
$error = '';

try {
    $pdo = Database::getConnection();

    // Handle Deletion
    $delete_id = filter_input(INPUT_GET, 'delete_id', FILTER_VALIDATE_INT);
    if ($delete_id) {
        $delStmt = $pdo->prepare("DELETE FROM bookings WHERE id = ?");
        $delStmt->execute([$delete_id]);
        header("Location: index.php?status=deleted");
        exit();
    }

    if (isset($_GET['status']) && $_GET['status'] === 'deleted') {
        $message = "Booking deleted successfully.";
    }

    // Fetch Bookings
    $stmt = $pdo->query("SELECT * FROM bookings ORDER BY id ASC");
    $bookings = $stmt->fetchAll();

    // Calculate Summaries
    $fares = array_column($bookings, 'fare');
    $totalFare = array_sum($fares);
    $count = count($fares);
    $averageFare = $count > 0 ? $totalFare / $count : 0;
    $highestFare = $count > 0 ? max($fares) : 0;

} catch (Exception $e) {
    $error = $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Management System</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h2>Transport Bookings Dashboard</h2>

        <?php if ($message): ?>
            <div class="alert alert-success"><?= htmlspecialchars($message) ?></div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="nav-links card">
            <a href="add_booking.php">Add New Booking</a>
            <a href="search.php">Search Bookings</a>
            <a href="export.php">Export CSV</a>
        </div>

        <div class="card">
            <h3>All Bookings</h3>
            <?php if (empty($bookings)): ?>
                <p>No booking records found.</p>
            <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Passenger Name</th>
                            <th>Destination</th>
                            <th>Fare</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($bookings as $b): ?>
                            <tr>
                                <td><?= htmlspecialchars((string)$b['id']) ?></td>
                                <td><?= htmlspecialchars($b['passenger_name']) ?></td>
                                <td><?= htmlspecialchars($b['destination']) ?></td>
                                <td class="<?= ($b['fare'] > 500) ? 'highlight' : '' ?>">
                                    $<?= number_format((float)$b['fare'], 2) ?>
                                </td>
                                <td>
                                    <a href="index.php?delete_id=<?= $b['id'] ?>" 
                                       class="btn btn-danger" 
                                       onclick="return confirm('Delete this record?');">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>

                <div class="summary-card">
                    <h3>Summary Report</h3>
                    <p><strong>Total Fare:</strong> $<?= number_format($totalFare, 2) ?></p>
                    <p><strong>Average Fare:</strong> $<?= number_format($averageFare, 2) ?></p>
                    <p><strong>Highest Fare:</strong> $<?= number_format($highestFare, 2) ?></p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>