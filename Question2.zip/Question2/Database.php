<?php
declare(strict_types=1);

class Database {
    private static ?PDO $instance = null;
    private static string $host = "localhost";
    private static string $dbname = "transport_company";
    private static string $username = "root";
    private static string $password = "password"; 

    private function __construct() {}

    public static function getConnection(): PDO {
        if (self::$instance === null) {
            $dsn = sprintf("mysql:host=%s;dbname=%s;charset=utf8mb4", self::$host, self::$dbname);
            
            $options = [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ];

            try {
                self::$instance = new PDO($dsn, self::$username, self::$password, $options);
            } catch (PDOException $e) {
                error_log("Connection failed: " . $e->getMessage());
                throw new Exception("Database connection failure. Check server configuration.");
            }
        }

        return self::$instance;
    }
}