<?php
declare(strict_types=1);
require_once 'Database.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $passenger_name = trim(filter_input(INPUT_POST, 'passenger_name') ?? '');
    $destination = trim(filter_input(INPUT_POST, 'destination') ?? '');
    $fare = filter_input(INPUT_POST, 'fare', FILTER_VALIDATE_FLOAT);

    if (empty($passenger_name) || empty($destination) || $fare === false || $fare <= 0) {
        $error = "Please provide valid booking details.";
    } else {
        try {
            $pdo = Database::getConnection();

            $stmt = $pdo->prepare("INSERT INTO bookings (passenger_name, destination, fare) VALUES (?, ?, ?)");
            $stmt->execute([$passenger_name, $destination, $fare]);
            $lastId = $pdo->lastInsertId();

            // Local CSV Backup execution
            $backupFile = 'backup.csv';
            $isNewFile = !file_exists($backupFile);
            $fileHandle = fopen($backupFile, 'a');

            if ($fileHandle) {
                if ($isNewFile) {
                    fputcsv($fileHandle, ['ID', 'Passenger Name', 'Destination', 'Fare']);
                }
                fputcsv($fileHandle, [$lastId, $passenger_name, $destination, number_format((float)$fare, 2, '.', '')]);
                fclose($fileHandle);
            }

            header("Location: index.php");
            exit();

        } catch (PDOException $e) {
            if ($e->getCode() === '23000') {
                $error = "Duplicate booking record detected.";
            } else {
                $error = "Database error: " . $e->getMessage();
            }
        } catch (Exception $e) {
            $error = $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Passenger Booking</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h2>Add Passenger Booking</h2>

        <?php if ($error): ?>
            <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card">
            <form method="POST" action="add_booking.php">
                <div class="form-group">
                    <label for="passenger_name">Passenger Name:</label>
                    <input type="text" id="passenger_name" name="passenger_name" required>
                </div>
                <div class="form-group">
                    <label for="destination">Destination:</label>
                    <input type="text" id="destination" name="destination" required>
                </div>
                <div class="form-group">
                    <label for="fare">Fare Amount:</label>
                    <input type="number" step="0.01" id="fare" name="fare" required>
                </div>
                <button type="submit" class="btn">Add Booking</button>
            </form>
        </div>

        <div class="nav-links">
            <a href="index.php">← Back to Dashboard</a>
        </div>
    </div>
</body>
</html>