<?php
declare(strict_types=1);
require_once 'Database.php';

$search_destination = trim(filter_input(INPUT_GET, 'destination') ?? '');
$results = [];
$searched = false;
$error = '';

if ($search_destination !== '') {
    $searched = true;
    try {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare("SELECT * FROM bookings WHERE destination LIKE ? ORDER BY id ASC");
        $stmt->execute(["%" . $search_destination . "%"]);
        $results = $stmt->fetchAll();
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Bookings</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h2>Search Bookings</h2>

        <?php if ($error): ?>
            <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card">
            <form method="GET" action="search.php">
                <div class="form-group">
                    <label for="destination">Destination:</label>
                    <input type="text" id="destination" name="destination" value="<?= htmlspecialchars($search_destination) ?>" required>
                </div>
                <button type="submit" class="btn">Search</button>
            </form>
        </div>

        <?php if ($searched): ?>
            <div class="card">
                <h3>Search Results for "<?= htmlspecialchars($search_destination) ?>"</h3>
                <?php if (empty($results)): ?>
                    <p>No records found matching that destination.</p>
                <?php else: ?>
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Passenger Name</th>
                                <th>Destination</th>
                                <th>Fare</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($results as $row): ?>
                                <tr>
                                    <td><?= htmlspecialchars((string)$row['id']) ?></td>
                                    <td><?= htmlspecialchars($row['passenger_name']) ?></td>
                                    <td><?= htmlspecialchars($row['destination']) ?></td>
                                    <td class="<?= ($row['fare'] > 500) ? 'highlight' : '' ?>">
                                        $<?= number_format((float)$row['fare'], 2) ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <div class="nav-links">
            <a href="index.php">← Back to Dashboard</a>
        </div>
    </div>
</body>
</html>