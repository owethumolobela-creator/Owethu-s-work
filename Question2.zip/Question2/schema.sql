CREATE DATABASE IF NOT EXISTS `transport_company` 
CHARACTER SET utf8mb4 
COLLATE utf8mb4_unicode_ci;

USE `transport_company`;

CREATE TABLE IF NOT EXISTS `bookings` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `passenger_name` VARCHAR(100) NOT NULL,
    `destination` VARCHAR(100) NOT NULL,
    `fare` DECIMAL(10,2) NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `unique_booking` (`passenger_name`, `destination`, `fare`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO `bookings` (`id`, `passenger_name`, `destination`, `fare`) VALUES
(1, 'Alice Karabo', 'Cape Town', 450.00),
(2, 'Tsholofelo Smith', 'Johannesburg', 600.00),
(3, 'Cynthia Neo Mosimane', 'Durban', 720.00),
(4, 'David Brown', 'Pretoria', 300.00),
(5, 'Thabo Molefe', 'Port Elizabeth', 550.00);