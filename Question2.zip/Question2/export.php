<?php
declare(strict_types=1);
require_once 'Database.php';

try {
    $pdo = Database::getConnection();

    $stmt = $pdo->query("SELECT id, passenger_name, destination, fare FROM bookings ORDER BY id ASC");
    $bookings = $stmt->fetchAll();

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=bookings_export_' . date('Y-m-d') . '.csv');

    $output = fopen('php://output', 'w');
    if ($output !== false) {
        fputcsv($output, ['ID', 'Passenger Name', 'Destination', 'Fare']);

        foreach ($bookings as $row) {
            fputcsv($output, [
                $row['id'],
                $row['passenger_name'],
                $row['destination'],
                number_format((float)$row['fare'], 2, '.', '')
            ]);
        }

        fclose($output);
    }
    exit();

} catch (Exception $e) {
    die("Export failed: " . $e->getMessage());
}