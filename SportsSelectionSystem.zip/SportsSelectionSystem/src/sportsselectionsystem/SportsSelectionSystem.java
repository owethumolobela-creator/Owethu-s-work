package sportsselectionsystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class SportsSelectionSystem extends JFrame {

    private JComboBox<String> categoryComboBox;
    private JPanel sportsPanel;
    private JButton submitButton, summaryButton;
    private JTextField individualCountField, partnerCountField, teamCountField;

    private ArrayList<String> selectedSports = new ArrayList<>();
    private int individualCount = 0, partnerCount = 0, teamCount = 0;

    private Map<String, String[]> sportsMap = new HashMap<>();

    public SportsSelectionSystem() {
        setTitle("Staff Sports Selection Module");
        setSize(500, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        sportsMap.put("Individual", new String[]{"Chess", "Boxing", "Swimming"});
        sportsMap.put("Partner", new String[]{"Table Tennis", "Badminton", "Tennis"});
        sportsMap.put("Team", new String[]{"Soccer", "Rugby", "Hockey"});

        JPanel topPanel = new JPanel();
        topPanel.add(new JLabel("Dept:"));
        topPanel.add(new JTextField("IT", 5));
        topPanel.add(new JLabel("Name"));
        topPanel.add(new JTextField("Odwa", 10));

        categoryComboBox = new JComboBox<>(new String[]{"Individual", "Partner", "Team"});
        topPanel.add(categoryComboBox);
        add(topPanel, BorderLayout.NORTH);

        sportsPanel = new JPanel();
        sportsPanel.setLayout(new BoxLayout(sportsPanel, BoxLayout.Y_AXIS));
        add(sportsPanel, BorderLayout.CENTER);
        updateSportsPanel("Individual");

        JPanel bottomPanel = new JPanel(new GridLayout(2, 4, 5, 5));
        submitButton = new JButton("Submit");
        summaryButton = new JButton("Show Summary");

        individualCountField = new JTextField("0", 5);
        partnerCountField = new JTextField("0", 5);
        teamCountField = new JTextField("0", 5);

        bottomPanel.add(new JLabel("Individual:"));
        bottomPanel.add(individualCountField);
        bottomPanel.add(new JLabel("Partner:"));
        bottomPanel.add(partnerCountField);
        bottomPanel.add(new JLabel("Team:"));
        bottomPanel.add(teamCountField);
        bottomPanel.add(submitButton);
        bottomPanel.add(summaryButton);
        add(bottomPanel, BorderLayout.SOUTH);

        categoryComboBox.addActionListener(e->{
            String category = (String) categoryComboBox.getSelectedItem();
            updateSportsPanel(category);
        });
        submitButton.addActionListener(e-> submitSelection());
        summaryButton.addActionListener(e-> showSummary());
    }
    private void updateSportsPanel(String category){
        sportsPanel.removeAll();
        String[] sports = sportsMap.get(category);
        for (String sport : sports){
            sportsPanel.add(new JCheckBox(sport));
        }
        sportsPanel.revalidate();
        sportsPanel.repaint();
    }
    private void submitSelection(){
        int count= 0;
        String category = (String) categoryComboBox.getSelectedItem();
        
        for(Component comp: sportsPanel.getComponents()){
            if(comp instanceof JCheckBox){
            JCheckBox checkBox = (JCheckBox) comp;
            if(checkBox.isSelected()){
                count++;
                selectedSports.add(checkBox.getText());
            }
          
        }
    }
        if(count> 2){
            JOptionPane.showMessageDialog(this,"Please select a maximum of two sports only!");
            return;
        }
        switch(category){
            case"Individual": individualCount += count;break;
            case"Partner": partnerCount += count;break;
            case"team":teamCount += count;break;
        }
    }
    private void showSummary(){
        individualCountField.setText(String.valueOf(individualCount));
        partnerCountField.setText(String.valueOf(partnerCount));
        teamCountField.setText(String.valueOf(teamCount));
        
        JOptionPane.showMessageDialog(this, "Selections so far:"+ selectedSports);
    }
    public static void main(String[] args){
        SwingUtilities.invokeLater(()->{
            new SportsSelectionSystem().setVisible(true);
          
        });
    }
}
