<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GlowWell Beauty Clinic - Management System</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <div class="nav-link">
            <a href="admin_dashboard.php">Switch to Admin Dashboard &rarr;</a>
        </div>
        <header>
            <h1>GlowWell Beauty Clinic</h1>
            <p>Online Booking & Management Portal</p>
        </header>

        <!-- Customer Registration Section -->
        <section class="card">
            <h2>Customer Registration</h2>
            <form id="registrationForm" action="php/register.php" method="POST" novalidate>
                <label>Full Name:</label>
                <input type="text" id="reg_name" name="name" required placeholder="Jane Doe">
                
                <label>Email Address:</label>
                <input type="email" id="reg_email" name="email" required placeholder="jane@example.com">
                
                <label>Password:</label>
                <input type="password" id="reg_password" name="password" required minlength="6">
                
                <button type="submit" name="register">Register Account</button>
            </form>
        </section>

        <!-- Online Appointment Booking Section -->
        <section class="card">
            <h2>Book an Appointment</h2>
            <form id="bookingForm" action="php/process_booking.php" method="POST">
                <label>Select Service:</label>
                <select name="service_id" required>
                    <option value="">-- Choose Service --</option>
                    <option value="1">Deep Cleansing Facial - R650</option>
                    <option value="2">Swedish Full Body Massage - R850</option>
                    <option value="3">Keratin Hair Treatment - R1200</option>
                </select>

                <label>Appointment Date:</label>
                <input type="date" id="appointment_date" name="appointment_date" required>

                <label>Appointment Time:</label>
                <input type="time" name="appointment_time" required>

                <button type="submit" name="book_appointment">Confirm Booking</button>
            </form>
        </section>
    </div>
    <script src="js/script.js"></script>
</body>
</html>