document.addEventListener('DOMContentLoaded', () => {
    // 1. Client-side validation for customer registration
    const regForm = document.getElementById('registrationForm');
    if (regForm) {
        regForm.addEventListener('submit', (e) => {
            const name = document.getElementById('reg_name').value.trim();
            const password = document.getElementById('reg_password').value;

            if (name === "") {
                alert("Error: Full name cannot be empty.");
                e.preventDefault();
                return;
            }
            if (password.length < 6) {
                alert("Error: Password must be at least 6 characters long.");
                e.preventDefault();
                return;
            }
        });
    }

    // 2. Client-side booking date validation (Prevent past dates)
    const bookingForm = document.getElementById('bookingForm');
    if (bookingForm) {
        bookingForm.addEventListener('submit', (e) => {
            const dateInput = document.getElementById('appointment_date').value;
            if (!dateInput) {
                alert("Please select a valid appointment date.");
                e.preventDefault();
                return;
            }
            const selectedDate = new Date(dateInput);
            const today = new Date();
            today.setHours(0,0,0,0);

            if (selectedDate < today) {
                alert("Error: You cannot book an appointment for a past date.");
                e.preventDefault();
            }
        });
    }
});