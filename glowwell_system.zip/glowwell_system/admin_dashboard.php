<?php
session_start();
require_once 'php/db.php';

// Fetch all bookings with customer and service details
$bookingsQuery = $pdo->query("SELECT b.id, u.name as customer, s.service_name, b.appointment_date, b.appointment_time, b.status FROM bookings b JOIN users u ON b.customer_id = u.id JOIN services s ON b.service_id = s.id");
$bookings = $bookingsQuery->fetchAll();

// Fetch staff schedules
$schedulesQuery = $pdo->query("SELECT ss.id, u.name as staff_name, ss.work_date, ss.start_time, ss.end_time FROM staff_schedules ss JOIN users u ON ss.staff_id = u.id");
$schedules = $schedulesQuery->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GlowWell - Admin Dashboard</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <div class="nav-link">
            <a href="index.php">&larr; Back to Client Portal</a>
        </div>
        <header>
            <h1>Administrator Dashboard</h1>
            <p>GlowWell Beauty Clinic Management Control Panel</p>
        </header>

        <!-- 1. View Bookings -->
        <section class="card">
            <h2>Customer Bookings Overview</h2>
            <table>
                <tr>
                    <th>ID</th>
                    <th>Customer</th>
                    <th>Service</th>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Status</th>
                </tr>
                <?php if (count($bookings) > 0): ?>
                    <?php foreach ($bookings as $b): ?>
                    <tr>
                        <td><?php echo $b['id']; ?></td>
                        <td><?php echo htmlspecialchars($b['customer']); ?></td>
                        <td><?php echo htmlspecialchars($b['service_name']); ?></td>
                        <td><?php echo $b['appointment_date']; ?></td>
                        <td><?php echo $b['appointment_time']; ?></td>
                        <td><strong><?php echo $b['status']; ?></strong></td>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="6" style="text-align: center;">No bookings found.</td></tr>
                <?php endif; ?>
            </table>
        </section>

        <!-- 2. Manage Staff Schedules -->
        <section class="card">
            <h2>Manage Staff Work Schedules</h2>
            <form action="php/admin_actions.php" method="POST">
                <input type="hidden" name="action" value="add_schedule">
                <label>Staff Member ID (e.g. 2 for Dr. Sarah):</label>
                <input type="number" name="staff_id" required>
                
                <label>Work Date:</label>
                <input type="date" name="work_date" required>
                
                <label>Start Time:</label>
                <input type="time" name="start_time" required>
                
                <label>End Time:</label>
                <input type="time" name="end_time" required>

                <button type="submit">Assign Staff Schedule</button>
            </form>

            <h3 style="margin-top: 20px; font-size: 1.1rem;">Existing Schedules</h3>
            <table>
                <tr>
                    <th>ID</th>
                    <th>Staff Name</th>
                    <th>Date</th>
                    <th>Start</th>
                    <th>End</th>
                </tr>
                <?php foreach ($schedules as $sc): ?>
                <tr>
                    <td><?php echo $sc['id']; ?></td>
                    <td><?php echo htmlspecialchars($sc['staff_name']); ?></td>
                    <td><?php echo $sc['work_date']; ?></td>
                    <td><?php echo $sc['start_time']; ?></td>
                    <td><?php echo $sc['end_time']; ?></td>
                </tr>
                <?php endforeach; ?>
            </table>
        </section>

        <!-- 3. Generate Reports -->
        <section class="card">
            <h2>Generate System Reports</h2>
            <form action="php/admin_actions.php" method="POST">
                <input type="hidden" name="action" value="generate_report">
                <label>Select Report Type:</label>
                <select name="report_type">
                    <option value="bookings_summary">Appointments Summary Report</option>
                    <option value="revenue_report">Monthly Revenue Estimate Report</option>
                </select>
                <button type="submit">Generate Report</button>
            </form>
        </section>
    </div>
</body>
</html>