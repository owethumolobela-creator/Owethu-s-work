<?php
session_start();
require_once 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['book_appointment'])) {
    $customer_id = $_SESSION['customer_id'] ?? 3; // Default test customer ID
    $service_id = filter_var($_POST['service_id'], FILTER_VALIDATE_INT);
    $appointment_date = $_POST['appointment_date'] ?? '';
    $appointment_time = $_POST['appointment_time'] ?? '';
    $staff_id = 2; // Default assigned staff member

    if (!$service_id || empty($appointment_date) || empty($appointment_time)) {
        die("<script>alert('Error: All booking fields are required.'); window.history.back();</script>");
    }

    try {
        $stmt = $pdo->prepare("INSERT INTO bookings (customer_id, service_id, staff_id, appointment_date, appointment_time, status) VALUES (?, ?, ?, ?, ?, 'Pending')");
        $stmt->execute([$customer_id, $service_id, $staff_id, $appointment_date, $appointment_time]);

        echo "<script>alert('Appointment successfully booked!'); window.location.href='../index.php';</script>";
    } catch (PDOException $e) {
        echo "<script>alert('Booking Error: " . addslashes($e->getMessage()) . "'); window.history.back();</script>";
    }
}
?>