<?php
require_once 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['register'])) {
    $name = htmlspecialchars(trim($_POST['name'] ?? ''));
    $email = filter_var(trim($_POST['email'] ?? ''), FILTER_VALIDATE_EMAIL);
    $password = $_POST['password'] ?? '';

    if (empty($name) || !$email || strlen($password) < 6) {
        die("<script>alert('Validation Error: Please provide valid inputs and a password of at least 6 characters.'); window.history.back();</script>");
    }

    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    try {
        $stmt = $pdo->prepare("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, 'Customer')");
        $stmt->execute([$name, $email, $hashedPassword]);
        
        echo "<script>alert('Registration successful! You can now book appointments.'); window.location.href='../index.php';</script>";
    } catch (PDOException $e) {
        echo "<script>alert('Database Error: Email address is already registered.'); window.history.back();</script>";
    }
}
?>