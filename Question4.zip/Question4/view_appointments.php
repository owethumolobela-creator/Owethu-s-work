<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM appointments WHERE user_id = :user_id ORDER BY appointment_date ASC");
$stmt->execute(['user_id' => $_SESSION['user_id']]);
$appointments = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html>
<head><title>My Appointments</title></head>
<body>
    <h2>Your Appointments</h2>
    <?php if (count($appointments) > 0): ?>
        <table border="1" cellpadding="8">
            <tr>
                <th>Title</th>
                <th>Date & Time</th>
                <th>Description</th>
            </tr>
            <?php foreach ($appointments as $app): ?>
                <tr>
                    <td><?= htmlspecialchars($app['title']) ?></td>
                    <td><?= htmlspecialchars($app['appointment_date']) ?></td>
                    <td><?= htmlspecialchars($app['description']) ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php else: ?>
        <p>No appointments found.</p>
    <?php endif; ?>
    <br><a href="dashboard.php">Back to Dashboard</a>
</body>
</html>