CREATE DATABASE IF NOT EXISTS beauty_parlor_db;
USE beauty_parlor_db;

-- Users table storing hashed passwords
CREATE TABLE IF NOT EXISTS users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL
);

-- Appointments table
CREATE TABLE IF NOT EXISTS appointments (
    appointment_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    appointment_date DATE NOT NULL,
    stylist VARCHAR(50) NOT NULL,
    notes TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- Seed default user (Password: password123)
-- Hash generated using password_hash('password123', PASSWORD_BCRYPT)
INSERT INTO users (email, password, full_name, phone) VALUES
('admin@example.com', 'password', 'Admin User', '0821234567');
UPDATE users 
SET password = 'password' 
WHERE email = 'admin@example.com';

-- Seed sample appointments
INSERT INTO appointments (user_id, appointment_date, stylist, notes) VALUES
(1, '2026-05-19', 'Tanya', 'Brush Cut and Dye'),
(1, '2026-03-31', 'Kuda', 'Dye'),
(1, '2026-05-04', 'Tanya', 'Plaiting');