<?php
$host = 'localhost';
$user = 'root';
$pass = 'password'; // Default XAMPP password is empty

try {
    // 1. Connect without selecting a database
    $pdo = new PDO("mysql:host=$host;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // 2. Create database if missing
    $pdo->exec("CREATE DATABASE IF NOT EXISTS appointment_system");
    $pdo->exec("USE appointment_system");

    // 3. Create tables if missing
    $pdo->exec("CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        full_name VARCHAR(100) NOT NULL,
        email VARCHAR(100) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");

    $pdo->exec("CREATE TABLE IF NOT EXISTS appointments (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        title VARCHAR(100) NOT NULL,
        appointment_date DATETIME NOT NULL,
        description TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    )");

    // 4. Insert default user
    $pdo->exec("INSERT INTO users (username, password, full_name, email) 
                VALUES ('admin', 'password', 'System Admin', 'admin@example.com')
                ON DUPLICATE KEY UPDATE id=id");

} catch (PDOException $e) {
    die("Database setup failed: " . $e->getMessage());
}
?>