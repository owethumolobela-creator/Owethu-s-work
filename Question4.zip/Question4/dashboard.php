<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head><title>Dashboard</title></head>
<body>
    <h2>Welcome, <?= htmlspecialchars($_SESSION['username']); ?>!</h2>
    <ul>
        <li><a href="add_appointment.php">Add Appointment</a></li>
        <li><a href="view_appointments.php">View Appointments</a></li>
        <li><a href="update_profile.php">Update Profile</a></li>
        <li><a href="logout.php">Logout</a></li>
    </ul>
</body>
</html>