<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

$message = '';
$user_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);

    if (!empty($full_name) && !empty($email)) {
        $stmt = $pdo->prepare("UPDATE users SET full_name = :full_name, email = :email WHERE id = :id");
        $stmt->execute(['full_name' => $full_name, 'email' => $email, 'id' => $user_id]);
        $message = "Profile updated successfully!";
    } else {
        $message = "Please fill in all fields.";
    }
}

$stmt = $pdo->prepare("SELECT * FROM users WHERE id = :id");
$stmt->execute(['id' => $user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html>
<head><title>Update Profile</title></head>
<body>
    <h2>Update Profile</h2>
    <?php if ($message): ?><p><?= htmlspecialchars($message) ?></p><?php endif; ?>
    <form method="POST">
        <label>Full Name:</label><br>
        <input type="text" name="full_name" value="<?= htmlspecialchars($user['full_name']) ?>" required><br><br>
        <label>Email:</label><br>
        <input type="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required><br><br>
        <button type="submit">Update</button>
    </form>
    <br><a href="dashboard.php">Back to Dashboard</a>
</body>
</html>