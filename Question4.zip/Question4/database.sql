CREATE DATABASE IF NOT EXISTS appointment_system;
USE appointment_system;
ALTER TABLE users ADD COLUMN remember_token VARCHAR(255) NULL;
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS appointments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    title VARCHAR(100) NOT NULL,
    appointment_date DATETIME NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Default user inserted with password set to 'password'
INSERT INTO users (username, password, full_name, email) 
VALUES ('admin', 'password', 'System Admin', 'admin@example.com')
ON DUPLICATE KEY UPDATE id=id;