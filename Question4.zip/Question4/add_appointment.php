<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title']);
    $date = $_POST['appointment_date'];
    $description = trim($_POST['description']);

    if (!empty($title) && !empty($date)) {
        $stmt = $pdo->prepare("INSERT INTO appointments (user_id, title, appointment_date, description) VALUES (:user_id, :title, :date, :description)");
        $stmt->execute([
            'user_id' => $_SESSION['user_id'],
            'title' => $title,
            'date' => $date,
            'description' => $description
        ]);
        $message = "Appointment added successfully!";
    } else {
        $message = "Please fill in required fields.";
    }
}
?>
<!DOCTYPE html>
<html>
<head><title>Add Appointment</title></head>
<body>
    <h2>Add Appointment</h2>
    <?php if ($message): ?><p><?= htmlspecialchars($message) ?></p><?php endif; ?>
    <form method="POST">
        <label>Title:</label><br>
        <input type="text" name="title" required><br><br>
        <label>Date & Time:</label><br>
        <input type="datetime-local" name="appointment_date" required><br><br>
        <label>Description:</label><br>
        <textarea name="description"></textarea><br><br>
        <button type="submit">Save Appointment</button>
    </form>
    <br><a href="dashboard.php">Back to Dashboard</a>
</body>
</html>