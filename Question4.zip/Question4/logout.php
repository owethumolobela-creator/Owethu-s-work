<?php
session_start();
require_once 'db.php';

// Safe update: Clear remember_token in DB if user is logged in and DB connection exists
if (isset($_SESSION['user_id']) && isset($pdo)) {
    try {
        $stmt = $pdo->prepare("UPDATE users SET remember_token = NULL WHERE id = :id");
        $stmt->execute(['id' => $_SESSION['user_id']]);
    } catch (PDOException $e) {
        // Log error silently or proceed with session destruction
    }
}

// Clear the 'remember_token' cookie from the browser
if (isset($_COOKIE['remember_token'])) {
    unset($_COOKIE['remember_token']);
    setcookie('remember_token', '', time() - 3600, '/');
}

// Destroy all session variables and clear the active session
session_unset();
session_destroy();

// Redirect back to login page
header("Location: index.php");
exit;
?>