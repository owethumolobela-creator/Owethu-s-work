<?php
require_once 'db.php';

// 1. Input Validation
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_POST['customer_code']) || empty($_POST['distance'])) {
    die("Error: Missing required input fields.");
}

$customer_code = trim($_POST['customer_code']);
$distance = filter_var($_POST['distance'], FILTER_VALIDATE_FLOAT);

if ($distance === false || $distance <= 0) {
    die("Error: Please enter a valid distance greater than 0.");
}

// 2. Secure Customer Retrieval via Prepared Statements
$stmt = $conn->prepare("SELECT customer_code, name, city FROM customers WHERE customer_code = ?");
$stmt->bind_param("s", $customer_code);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("Error: Selected customer does not exist.");
}

$customer = $result->fetch_assoc();
$stmt->close();

// 3. Business Logic Calculations
$rate_per_km = 45;       // R45 per km
$labour_rate_pct = 0.05; // 5% of distance charge
$hours_per_km = 4.5;    // 4.5 hours per km
$hourly_rate = 1250;     // R1250 per hour
$vat_rate = 0.15;        // 15% VAT

$distance_charge = $distance * $rate_per_km;
$labour_cost = $distance_charge * $labour_rate_pct;
$total_hours = $distance * $hours_per_km;
$hourly_cost = $total_hours * $hourly_rate;

$subtotal = $distance_charge + $labour_cost + $hourly_cost;
$vat = $subtotal * $vat_rate;
$total_project_cost = $subtotal + $vat;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Project Cost Breakdown</title>
</head>
<body>
    <h2>Project Cost Breakdown</h2>
    <p><strong>Customer Code:</strong> <?= htmlspecialchars($customer['customer_code']); ?></p>
    <p><strong>Customer Name:</strong> <?= htmlspecialchars($customer['name']); ?></p>
    <p><strong>City:</strong> <?= htmlspecialchars($customer['city']); ?></p>
    <p><strong>Distance:</strong> <?= htmlspecialchars($distance); ?> km</p>
    <p><strong>Total Work Time:</strong> <?= htmlspecialchars($total_hours); ?> hours</p>
    <p><strong>Labour Cost:</strong> R<?= number_format($labour_cost, 2); ?></p>
    <p><strong>Total Cost Before 15% VAT:</strong> R<?= number_format($subtotal, 2); ?></p>
    <p><strong>VAT (15%):</strong> R<?= number_format($vat, 2); ?></p>
    <p><strong>Total Project Cost:</strong> R<?= number_format($total_project_cost, 2); ?></p>
    <br>
    <a href="index.php">Back to Booking Form</a>
</body>
</html>