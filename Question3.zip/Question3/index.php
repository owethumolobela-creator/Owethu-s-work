<?php
require_once 'db.php';

// Fetch registered customers to populate dropdown
$query = "SELECT customer_code, name FROM customers";
$result = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Earthmoving Booking Form</title>
</head>
<body>
    <h2>Earthmoving Booking Form</h2>
    <form action="process_booking.php" method="POST">
        <label for="customer_code">Customer:</label>
        <select name="customer_code" id="customer_code" required>
            <option value="">-- Select Customer --</option>
            <?php while ($row = $result->fetch_assoc()): ?>
                <option value="<?= htmlspecialchars($row['customer_code']); ?>">
                    <?= htmlspecialchars($row['customer_code'] . ' - ' . $row['name']); ?>
                </option>
            <?php endwhile; ?>
        </select>
        <br><br>

        <label for="distance">Distance (km):</label>
        <input type="number" name="distance" id="distance" min="1" step="any" required>
        <br><br>

        <input type="submit" value="Calculate Project Cost">
    </form>
</body>
</html>