CREATE DATABASE IF NOT EXISTS earthmoving_db;
USE earthmoving_db;

CREATE TABLE IF NOT EXISTS customers (
    customer_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_code VARCHAR(10) NOT NULL UNIQUE,
    name VARCHAR(100) NOT NULL,
    city VARCHAR(50) NOT NULL
);

-- Seed sample data
INSERT INTO customers (customer_code, name, city) VALUES
('C001', 'Alpha Construction', 'Cape Town'),
('C002', 'Beta Developments', 'Johannesburg'),
('C003', 'Gamma Civils', 'Durban');