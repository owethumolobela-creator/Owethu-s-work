<?php
$host = 'localhost';
$user = 'root';
$password = 'password';
$dbname = 'earthmoving_db';

$conn = new mysqli($host, $user, $password, $dbname);

if ($conn->connect_error) {
    die("Database Connection Failed: " . $conn->connect_error);
}
?>