/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package studentmanagersystem;

/**
 *
 * @author Future CEO
 */
import java.util.ArrayList;

public class StudentManager {
    private ArrayList<Student> students = new ArrayList<>();

    public void addStudent(Student student) {
        students.add(student);
    }

    public void displayAllStudents() {
        if (students.isEmpty()) {
            System.out.println("No student records found.");
        } else {
            for (Student s : students) {
                System.out.println(s);
            }
        }
    }

    public Student searchStudentByID(String studentID) {
        for (Student s : students) {
            if (s.getStudentID().equalsIgnoreCase(studentID)) {
                return s;
            }
        }
        return null;
    }

    public boolean removeStudentByID(String studentID) {
        Student s = searchStudentByID(studentID);
        if (s != null) {
            students.remove(s);
            return true;
        }
        return false;
    }

    public boolean updateStudent(String studentID, String newName, int newAge) {
        Student s = searchStudentByID(studentID);
        if (s != null) {
            s.setName(newName);
            s.setAge(newAge);
            return true;
        }
        return false;
    }
}

