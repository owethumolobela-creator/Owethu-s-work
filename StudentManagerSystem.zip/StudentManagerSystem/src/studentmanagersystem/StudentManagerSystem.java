/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package studentmanagersystem;

/**
 *
 * @author Future CEO
 */
import java.util.Scanner;

public class StudentManagerSystem {
    public static void main(String[] args) {
        StudentManager manager = new StudentManager();
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n--- Student Management System ---");
            System.out.println("1. Add Student");
            System.out.println("2. Display All Students");
            System.out.println("3. Search Student by ID");
            System.out.println("4. Remove Student by ID");
            System.out.println("5. Update Student Details");
            System.out.println("0. Exit");
            System.out.print("Enter your choice: ");

            while (!scanner.hasNextInt()) {
                System.out.print("Invalid input. Enter a number: ");
                scanner.next();
            }

            choice = scanner.nextInt();
            scanner.nextLine(); // Clear buffer

            switch (choice) {
                case 1:
                    System.out.print("Enter Student ID: ");
                    String id = scanner.nextLine();
                    System.out.print("Enter Name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter Age: ");
                    int age = readValidAge(scanner);
                    manager.addStudent(new Student(id, name, age));
                    System.out.println("Student added.");
                    break;

                case 2:
                    manager.displayAllStudents();
                    break;

                case 3:
                    System.out.print("Enter Student ID to search: ");
                    String searchID = scanner.nextLine();
                    Student found = manager.searchStudentByID(searchID);
                    if (found != null) {
                        System.out.println("Student Found: " + found);
                    } else {
                        System.out.println("Student not found.");
                    }
                    break;

                case 4:
                    System.out.print("Enter Student ID to remove: ");
                    String removeID = scanner.nextLine();
                    if (manager.removeStudentByID(removeID)) {
                        System.out.println("Student removed.");
                    } else {
                        System.out.println("Student not found.");
                    }
                    break;

                case 5:
                    System.out.print("Enter Student ID to update: ");
                    String updateID = scanner.nextLine();
                    Student student = manager.searchStudentByID(updateID);
                    if (student != null) {
                        System.out.print("Enter new name: ");
                        String newName = scanner.nextLine();
                        System.out.print("Enter new age: ");
                        int newAge = readValidAge(scanner);
                        manager.updateStudent(updateID, newName, newAge);
                        System.out.println("Student details updated.");
                    } else {
                        System.out.println("Student not found.");
                    }
                    break;

                case 0:
                    System.out.println("Exiting system.");
                    break;

                default:
                    System.out.println("Invalid choice.");
            }
        } while (choice != 0);

        scanner.close();
    }

    // ✅ Input validation for age — *[5 marks]*
    private static int readValidAge(Scanner scanner) {
        int age;
        while (true) {
            while (!scanner.hasNextInt()) {
                System.out.print("Invalid input. Enter a valid age: ");
                scanner.next();
            }
            age = scanner.nextInt();
            scanner.nextLine(); // Clear buffer
            if (age >= 0) {
                return age;
            } else {
                System.out.print("Age cannot be negative. Enter again: ");
            }
        }
    }
}
