CREATE DATABASE IF NOT EXISTS inventory;
USE inventory;

CREATE TABLE IF NOT EXISTS warehouse_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    item_name VARCHAR(255) NOT NULL,
    quantity INT NOT NULL CHECK (quantity >= 0),
    supplier VARCHAR(255) NOT NULL,
    category VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT unique_item_supplier UNIQUE (item_name, supplier) -- Duplicate prevention rule
);

-- Initial seed data
INSERT INTO warehouse_items (item_name, quantity, supplier, category) VALUES
('Laptop 15', 10, 'TechWorld Supplies', 'Electronics'),
('Office Chair', 25, 'Furnish Hub', 'Furniture'),
('Printer Paper', 100, 'Stationery Depot', 'Stationery'),
('Desk Calculator', 28, 'ABC Digital', 'Electronics'),
('Gaming Mouse', 125, 'Digital Mouse International', 'Electronics'),
('A4 Diary', 250, 'Kingston Stationery', 'Stationery'),
('A5 Diary', 120, 'Kingston Stationery', 'Stationery'),
('A4 Notepad 96 pages', 80, 'Waltons', 'Stationery'),
('A4 Notepad 192 pages', 50, 'Waltons', 'Stationery');