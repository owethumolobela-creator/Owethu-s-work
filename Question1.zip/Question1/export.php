<?php

/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHP.php to edit this template
 */
require_once "Inventory.php";

$inventory = new Inventory();
$items = $inventory->getAllItems();

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=inventory_export.csv');

$output = fopen('php://output', 'w');
fputcsv($output, ['ID', 'Item', 'Quantity', 'Supplier', 'Category']);

foreach ($items as $item) {
    fputcsv($output, [
        $item['id'],
        $item['item_name'],
        $item['quantity'],
        $item['supplier'],
        $item['category']
    ]);
}

fclose($output);
exit();
?>
