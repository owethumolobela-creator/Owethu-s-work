<?php

/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHP.php to edit this template
 */

require_once "Database.php";

class Inventory {
    private $conn;
    private $table_name = "warehouse_items";

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function addItem($itemName, $quantity, $supplier, $category) {
        if (!$this->conn) return ["success" => false, "message" => "No database connection."];

        try {
            $this->conn->beginTransaction();

            $query = "INSERT INTO " . $this->table_name . " (item_name, quantity, supplier, category) VALUES (:item_name, :quantity, :supplier, :category)";
            $stmt = $this->conn->prepare($query);

            $stmt->bindParam(":item_name", $itemName);
            $stmt->bindParam(":quantity", $quantity, PDO::PARAM_INT);
            $stmt->bindParam(":supplier", $supplier);
            $stmt->bindParam(":category", $category);

            $stmt->execute();
            $this->conn->commit();

            $this->appendToBackupCSV($itemName, $quantity, $supplier, $category);

            return ["success" => true, "message" => "Item added and backed up successfully."];

        } catch (PDOException $e) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            if ($e->getCode() == 23000) {
                return ["success" => false, "message" => "Duplicate entry detected! This item and supplier combination already exists."];
            }
            return ["success" => false, "message" => "Database Error: " . $e->getMessage()];
        }
    }

    private function appendToBackupCSV($itemName, $quantity, $supplier, $category) {
        $file = fopen("backup.csv", "a");
        if ($file) {
            fputcsv($file, [$itemName, $quantity, $supplier, $category]);
            fclose($file);
        }
    }

    public function searchBySupplier($supplier) {
        if (!$this->conn) return [];
        $query = "SELECT * FROM " . $this->table_name . " WHERE supplier LIKE :supplier ORDER BY id ASC";
        $stmt = $this->conn->prepare($query);
        $searchTerm = "%" . $supplier . "%";
        $stmt->bindParam(":supplier", $searchTerm);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function getAllItems() {
        if (!$this->conn) return [];
        $query = "SELECT * FROM " . $this->table_name . " ORDER BY id ASC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll();
    }
}
?>