<?php

/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHP.php to edit this template
 */
header('Content-Type: application/json');
require_once "Inventory.php";

$inventory = new Inventory();
$action = $_GET['action'] ?? $_POST['action'] ?? '';

if ($_SERVER["REQUEST_METHOD"] === "POST" && $action === 'add') {
    $itemName = trim($_POST['item_name'] ?? '');
    $quantity = trim($_POST['quantity'] ?? '');
    $supplier = trim($_POST['supplier'] ?? '');
    $category = trim($_POST['category'] ?? '');

    if (empty($itemName) || empty($quantity) || empty($supplier) || empty($category)) {
        echo json_encode(["success" => false, "message" => "All fields are required."]);
    } elseif (!is_numeric($quantity) || (int)$quantity < 0) {
        echo json_encode(["success" => false, "message" => "Quantity must be a non-negative integer."]);
    } else {
        $result = $inventory->addItem($itemName, (int)$quantity, $supplier, $category);
        echo json_encode($result);
    }
    exit();
}

if ($_SERVER["REQUEST_METHOD"] === "GET" && $action === 'fetch') {
    $supplier = trim($_GET['supplier'] ?? '');
    if (!empty($supplier)) {
        $items = $inventory->searchBySupplier($supplier);
    } else {
        $items = $inventory->getAllItems();
    }
    echo json_encode(["success" => true, "data" => $items]);
    exit();
}

echo json_encode(["success" => false, "message" => "Invalid Request"]);
exit();
?>
