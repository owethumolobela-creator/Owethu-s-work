<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>System Login - Tutoring Management</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h1>Tutoring Booking & Student Management System</h1>
        <h2>User Login (RBAC Authentication)</h2>
        <form action="php/auth.php" method="POST">
            <label>Email Address:</label>
            <input type="email" name="email" required placeholder="name@example.com">
            
            <label>Password:</label>
            <input type="password" name="password" required>
            
            <button type="submit" name="login">Log In</button>
        </form>
        <p style="text-align: center; margin-top: 15px;">Need an account? <a href="register.php">Register here</a></p>
    </div>
</body>
</html>