document.addEventListener('DOMContentLoaded', () => {
    // 1. Client-Side Form Validation[cite: 22]
    const regForm = document.getElementById('registrationForm');
    if (regForm) {
        regForm.addEventListener('submit', (e) => {
            const name = document.getElementById('full_name').value.trim();
            const pass = document.getElementById('password').value;
            if (name === "" || pass.length < 6) {
                alert("Validation Error: Name cannot be empty and password must be at least 6 characters.");
                e.preventDefault();
            }
        });
    }

    // 2. Weekday Validation for Bookings[cite: 22]
    const bookingForm = document.getElementById('bookingForm');
    if (bookingForm) {
        bookingForm.addEventListener('submit', (e) => {
            const dateInput = document.getElementById('booking_date').value;
            if (!dateInput) {
                alert("Please select a session date.");
                e.preventDefault();
                return;
            }
            const parts = dateInput.split('-').map(Number);
            const selectedDate = new Date(parts[0], parts[1] - 1, parts[2]);
            const day = selectedDate.getDay(); // 0 = Sunday, 6 = Saturday
            if (day === 0 || day === 6) {
                alert("Scheduling Error: Tutoring sessions can only be booked from Monday to Friday.");
                e.preventDefault();
            }
        });
    }

    // 3. JavaScript Arrays and Objects for Dynamic Session Management[cite: 22]
    const activeTutoringSchedules = [
        { id: 101, subject: "Advanced Mathematics", day: "Monday", time: "09:00 - 10:00", tutor: "Dr. Alice Smith" },
        { id: 102, subject: "Data Science Fundamentals", day: "Wednesday", time: "14:00 - 15:00", tutor: "Prof. Bob Jones" }
    ];

    const displaySchedulesToConsole = () => {
        console.group("--- Active System Tutoring Schedules (JS Object & Array) ---");
        activeTutoringSchedules.forEach(item => {
            console.log(`Session #${item.id} | ${item.subject} | ${item.day} at ${item.time} | Tutor: ${item.tutor}`);
        });
        console.groupEnd();
    };

    displaySchedulesToConsole();
});