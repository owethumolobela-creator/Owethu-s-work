<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Student') {
    header("Location: login.php");
    exit;
}
require_once 'php/db.php';
$student_id = $_SESSION['user_id'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Portal - Tutoring System</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <div class="nav-bar">
            Welcome, <strong><?php echo htmlspecialchars($_SESSION['full_name']); ?></strong> | <a href="php/logout.php">Logout</a>
        </div>
        <h1>Student Dashboard</h1>

        <!-- Programme Selection & Payment[cite: 20] -->
        <h2>Programme Selection & Payment Submission</h2>
        <form action="php/payment_process.php" method="POST">
            <label>Select Programme:</label>
            <select name="programme_id" required>
                <option value="">-- Choose Programme --</option>
                <option value="1">Advanced Mathematics - R1,500.00</option>
                <option value="2">Data Science Fundamentals - R1,800.00</option>
            </select>
            <label>Payment Method:</label>
            <select name="payment_method" required>
                <option value="card">Credit / Debit Card</option>
                <option value="eft">EFT Direct Transfer</option>
            </select>
            <button type="submit" name="make_payment">Submit Payment & Enrol</button>
        </form>

        <!-- Session Booking[cite: 20] -->
        <h2>Book Tutoring Session (Monday - Friday)</h2>
        <form id="bookingForm" action="php/booking_process.php" method="POST">
            <label>Select Programme:</label>
            <select name="programme_id" required>
                <option value="1">Advanced Mathematics</option>
                <option value="2">Data Science Fundamentals</option>
            </select>
            <label>Select Tutor:</label>
            <select name="tutor_id" required>
                <?php
                $tutors = $pdo->query("SELECT user_id, full_name FROM users WHERE role = 'Tutor'")->fetchAll();
                foreach($tutors as $t) {
                    echo "<option value='{$t['user_id']}'>{$t['full_name']}</option>";
                }
                ?>
            </select>
            <label>Session Date (Monday-Friday):</label>
            <input type="date" id="booking_date" name="booking_date" required>
            <label>Start Time:</label>
            <input type="time" name="start_time" required>
            <label>End Time:</label>
            <input type="time" name="end_time" required>
            <button type="submit" name="book_session">Confirm Booking</button>
        </form>
    </div>
    <script src="js/script.js"></script>
</body>
</html>