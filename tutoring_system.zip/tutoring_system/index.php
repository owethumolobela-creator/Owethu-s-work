<?php
session_start();
// If the user is already authenticated, redirect them to their respective role-based dashboard
if (isset($_SESSION['user_id'])) {
    if ($_SESSION['role'] === 'Admin') {
        header("Location: admin_dashboard.php");
    } elseif ($_SESSION['role'] === 'Tutor') {
        header("Location: tutor_dashboard.php");
    } else {
        header("Location: student_dashboard.php");
    }
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome - Tutoring Booking & Student Management System</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container" style="text-align: center; padding: 60px 20px;">
        <h1>Tutoring Booking & Student Management System</h1>
        <p style="margin-bottom: 30px; font-size: 1.1rem; color: #555;">
            Welcome to the official Mathematics and Data Science Tutoring Portal[cite: 20]. Please choose an option below to get started.
        </p>
        <div style="display: flex; justify-content: center; gap: 20px;">
            <a href="login.php" style="padding: 12px 30px; background-color: #1a73e8; color: white; text-decoration: none; border-radius: 4px; font-weight: bold; font-size: 15px;">Log In</a>
            <a href="register.php" style="padding: 12px 30px; background-color: #28a745; color: white; text-decoration: none; border-radius: 4px; font-weight: bold; font-size: 15px;">Register Account</a>
        </div>
    </div>
</body>
</html>