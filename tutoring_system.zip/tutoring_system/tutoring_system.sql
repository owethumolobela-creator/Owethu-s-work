CREATE DATABASE IF NOT EXISTS tutoring_system CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE tutoring_system;

-- 1. Users Table (Supports RBAC for Students, Tutors, and Administrators)
CREATE TABLE IF NOT EXISTS users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('Student', 'Tutor', 'Admin') DEFAULT 'Student',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. Programmes Table (Mathematics & Data Science)
CREATE TABLE IF NOT EXISTS programmes (
    programme_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    description TEXT,
    fee DECIMAL(10,2) NOT NULL
);

-- 3. Payments Table (Links Students to Programmes)
CREATE TABLE IF NOT EXISTS payments (
    payment_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    programme_id INT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    status ENUM('Pending', 'Completed', 'Failed') DEFAULT 'Completed',
    payment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (programme_id) REFERENCES programmes(programme_id) ON DELETE CASCADE
);

-- 4. Tutor Availability Table
CREATE TABLE IF NOT EXISTS tutor_availability (
    availability_id INT AUTO_INCREMENT PRIMARY KEY,
    tutor_id INT NOT NULL,
    day_of_week ENUM('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday') NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    FOREIGN KEY (tutor_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- 5. Bookings Table (Weekday Tutoring Sessions)
CREATE TABLE IF NOT EXISTS bookings (
    booking_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    tutor_id INT NOT NULL,
    programme_id INT NOT NULL,
    booking_date DATE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    status ENUM('Requested', 'Confirmed', 'Completed', 'Cancelled') DEFAULT 'Requested',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (tutor_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (programme_id) REFERENCES programmes(programme_id) ON DELETE CASCADE
);

-- Sample Data Insertion (Passwords hashed via Bcrypt for testing)
INSERT INTO programmes (title, description, fee) VALUES 
('Advanced Mathematics', 'Calculus, Linear Algebra, and Differential Equations', 1500.00),
('Data Science Fundamentals', 'Python, Statistics, and Machine Learning Basics', 1800.00)
ON DUPLICATE KEY UPDATE title=VALUES(title);

-- Default Users: Admin (admin@tutor.com), Tutor (tutor@tutor.com), Student (student@tutor.com) -> Password: password123
INSERT INTO users (full_name, email, password_hash, role) VALUES 
('System Administrator', 'admin@tutor.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Admin'),
('Dr. Alice Smith', 'tutor@tutor.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Tutor'),
('John Student', 'student@tutor.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Student')
ON DUPLICATE KEY UPDATE full_name=VALUES(full_name);