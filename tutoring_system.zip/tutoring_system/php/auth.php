<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $email = filter_var(trim($_POST['email'] ?? ''), FILTER_VALIDATE_EMAIL);
    $password = $_POST['password'] ?? '';

    if (!$email || empty($password)) {
        die("<script>alert('Error: Please provide a valid email and password.'); window.history.back();</script>");
    }

    try {
        $stmt = $pdo->prepare("SELECT user_id, full_name, email, password_hash, role FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password_hash'])) { //[cite: 23]
            session_regenerate_id(true);
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['full_name'] = $user['full_name'];
            $_SESSION['role'] = $user['role'];

            // Role-Based Access Control (RBAC) Redirection
            if ($user['role'] === 'Admin') {
                header("Location: ../admin_dashboard.php");
            } elseif ($user['role'] === 'Tutor') {
                header("Location: ../tutor_dashboard.php");
            } else {
                header("Location: ../student_dashboard.php");
            }
            exit;
        } else {
            echo "<script>alert('Error: Invalid email or password combination.'); window.history.back();</script>";
        }
    } catch (PDOException $e) {
        echo "<script>alert('System Error during login authentication.'); window.history.back();</script>";
    }
}
?>