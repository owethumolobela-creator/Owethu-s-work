<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Student') {
    die("Access Denied.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['book_session'])) {
    $student_id = $_SESSION['user_id'];
    $tutor_id = filter_var($_POST['tutor_id'], FILTER_VALIDATE_INT);
    $programme_id = filter_var($_POST['programme_id'], FILTER_VALIDATE_INT);
    $booking_date = $_POST['booking_date'] ?? '';
    $start_time = $_POST['start_time'] ?? '';
    $end_time = $_POST['end_time'] ?? '';

    // Enforce Weekday Rule (Monday - Friday)[cite: 5, 22]
    $dayOfWeek = date('l', strtotime($booking_date));
    if (in_array($dayOfWeek, ['Saturday', 'Sunday'])) {
        die("<script>alert('Business Rule Error: Tutoring sessions can only be booked from Monday to Friday.'); window.history.back();</script>");
    }

    try {
        $stmt = $pdo->prepare("INSERT INTO bookings (student_id, tutor_id, programme_id, booking_date, start_time, end_time, status) VALUES (?, ?, ?, ?, ?, ?, 'Requested')");
        $stmt->execute([$student_id, $tutor_id, $programme_id, $booking_date, $start_time, $end_time]);

        echo "<script>alert('Tutoring session successfully booked and notification dispatched!'); window.location.href='../student_dashboard.php';</script>";
    } catch (PDOException $e) {
        echo "<script>alert('Booking Error: ' + " . json_encode($e->getMessage()) . "); window.history.back();</script>";
    }
}
?>