<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Admin') {
    die("Access Denied.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // CRUD: Delete User
    if ($action === 'delete_user') {
        $target_id = filter_var($_POST['user_id'], FILTER_VALIDATE_INT);
        $stmt = $pdo->prepare("DELETE FROM users WHERE user_id = ?");
        $stmt->execute([$target_id]);
        echo "<script>alert('User record successfully deleted.'); window.location.href='../admin_dashboard.php';</script>";
    }
    // CRUD: Confirm Booking Status Override
    elseif ($action === 'confirm_booking') {
        $booking_id = filter_var($_POST['booking_id'], FILTER_VALIDATE_INT);
        $stmt = $pdo->prepare("UPDATE bookings SET status = 'Confirmed' WHERE booking_id = ?");
        $stmt->execute([$booking_id]);
        echo "<script>alert('Booking status updated to Confirmed.'); window.location.href='../admin_dashboard.php';</script>";
    }
}
?>