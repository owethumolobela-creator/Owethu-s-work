<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Student') {
    die("Access Denied.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['make_payment'])) {
    $student_id = $_SESSION['user_id'];
    $programme_id = filter_var($_POST['programme_id'], FILTER_VALIDATE_INT);
    $amount = ($programme_id === 1) ? 1500.00 : 1800.00;

    if (!$programme_id) {
        die("<script>alert('Invalid programme selection.'); window.history.back();</script>");
    }

    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare("INSERT INTO payments (user_id, programme_id, amount, status) VALUES (?, ?, ?, 'Completed')");
        $stmt->execute([$student_id, $programme_id, $amount]);

        $pdo->commit();
        echo "<script>alert('Payment verified and programme enrolment successful!'); window.location.href='../student_dashboard.php';</script>";
    } catch (Exception $e) {
        $pdo->rollBack();
        echo "<script>alert('Payment transaction failed.'); window.history.back();</script>";
    }
}
?>