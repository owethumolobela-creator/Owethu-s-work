<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Tutor') {
    die("Access Denied.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['set_availability'])) {
    $tutor_id = $_SESSION['user_id'];
    $day_of_week = $_POST['day_of_week'] ?? '';
    $start_time = $_POST['start_time'] ?? '';
    $end_time = $_POST['end_time'] ?? '';

    if (!in_array($day_of_week, ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'])) {
        die("<script>alert('Error: Availability can only be set for weekdays.'); window.history.back();</script>");
    }

    try {
        $stmt = $pdo->prepare("INSERT INTO tutor_availability (tutor_id, day_of_week, start_time, end_time) VALUES (?, ?, ?, ?)");
        $stmt->execute([$tutor_id, $day_of_week, $start_time, $end_time]);
        echo "<script>alert('Availability schedule updated successfully!'); window.location.href='../tutor_dashboard.php';</script>";
    } catch (PDOException $e) {
        echo "<script>alert('Database Error updating availability.'); window.history.back();</script>";
    }
}
?>