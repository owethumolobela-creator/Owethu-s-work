<?php
require_once 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['register'])) {
    $full_name = htmlspecialchars(trim($_POST['full_name'] ?? ''), ENT_QUOTES, 'UTF-8');
    $email = filter_var(trim($_POST['email'] ?? ''), FILTER_VALIDATE_EMAIL);
    $password = $_POST['password'] ?? '';
    $role = $_POST['role'] ?? 'Student';

    if (empty($full_name) || !$email || strlen($password) < 6 || !in_array($role, ['Student', 'Tutor', 'Admin'])) {
        die("<script>alert('Validation Error: Check your inputs. Password must be at least 6 characters.'); window.history.back();</script>");
    }

    $password_hash = password_hash($password, PASSWORD_BCRYPT); //[cite: 23]

    try {
        $stmt = $pdo->prepare("INSERT INTO users (full_name, email, password_hash, role) VALUES (?, ?, ?, ?)");
        $stmt->execute([$full_name, $email, $password_hash, $role]);
        echo "<script>alert('Registration successful! Please proceed to login.'); window.location.href='../login.php';</script>";
    } catch (PDOException $e) {
        echo "<script>alert('Registration Error: Email address is already registered.'); window.history.back();</script>";
    }
}
?>