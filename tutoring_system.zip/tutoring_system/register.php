<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>System Registration - Tutoring Management</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h1>Tutoring Booking & Student Management System</h1>
        <h2>User Registration</h2>
        <form id="registrationForm" action="php/reg_process.php" method="POST">
            <label>Full Name:</label>
            <input type="text" id="full_name" name="full_name" required placeholder="Enter full name">
            
            <label>Email Address:</label>
            <input type="email" id="email" name="email" required placeholder="name@example.com">
            
            <label>Password (Min 6 characters):</label>
            <input type="password" id="password" name="password" required minlength="6">
            
            <label>System Role:</label>
            <select name="role" required>
                <option value="Student">Student</option>
                <option value="Tutor">Tutor</option>
                <option value="Admin">Administrator</option>
            </select>
            
            <button type="submit" name="register">Register Account</button>
        </form>
        <p style="text-align: center; margin-top: 15px;">Already have an account? <a href="login.php">Log In here</a></p>
    </div>
    <script src="js/script.js"></script>
</body>
</html>