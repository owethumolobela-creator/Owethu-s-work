<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Admin') {
    header("Location: login.php");
    exit;
}
require_once 'php/db.php';
$users = $pdo->query("SELECT * FROM users")->fetchAll();
$bookings = $pdo->query("SELECT b.*, u.full_name as student_name FROM bookings b JOIN users u ON b.student_id = u.user_id")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard - Tutoring System</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <div class="nav-bar">
            Administrator: <strong><?php echo htmlspecialchars($_SESSION['full_name']); ?></strong> | <a href="php/logout.php">Logout</a>
        </div>
        <h1>Administrator Control Panel</h1>

        <h2>User Registrations & CRUD Oversight</h2>
        <table>
            <tr><th>ID</th><th>Name</th><th>Email</th><th>Role</th><th>Actions</th></tr>
            <?php foreach($users as $u): ?>
            <tr>
                <td><?php echo $u['user_id']; ?></td>
                <td><?php echo htmlspecialchars($u['full_name']); ?></td>
                <td><?php echo htmlspecialchars($u['email']); ?></td>
                <td><?php echo $u['role']; ?></td>
                <td>
                    <form action="php/admin_process.php" method="POST" style="padding:0; background:none; border:none;">
                        <input type="hidden" name="action" value="delete_user">
                        <input type="hidden" name="user_id" value="<?php echo $u['user_id']; ?>">
                        <button type="submit" style="background:#d93025; padding:5px 10px; font-size:12px;">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
        </table>

        <h2>System Bookings Management</h2>
        <table>
            <tr><th>ID</th><th>Student</th><th>Date</th><th>Time</th><th>Status</th><th>Override</th></tr>
            <?php foreach($bookings as $b): ?>
            <tr>
                <td><?php echo $b['booking_id']; ?></td>
                <td><?php echo htmlspecialchars($b['student_name']); ?></td>
                <td><?php echo $b['booking_date']; ?></td>
                <td><?php echo $b['start_time']; ?></td>
                <td><?php echo $b['status']; ?></td>
                <td>
                    <form action="php/admin_process.php" method="POST" style="padding:0; background:none; border:none;">
                        <input type="hidden" name="action" value="confirm_booking">
                        <input type="hidden" name="booking_id" value="<?php echo $b['booking_id']; ?>">
                        <button type="submit" style="background:#28a745; padding:5px 10px; font-size:12px;">Confirm</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
        </table>
    </div>
</body>
</html>