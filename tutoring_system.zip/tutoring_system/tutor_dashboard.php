<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Tutor') {
    header("Location: login.php");
    exit;
}
require_once 'php/db.php';
$tutor_id = $_SESSION['user_id'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Tutor Portal - Tutoring System</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <div class="nav-bar">
            Tutor: <strong><?php echo htmlspecialchars($_SESSION['full_name']); ?></strong> | <a href="php/logout.php">Logout</a>
        </div>
        <h1>Tutor Schedule Management</h1>

        <!-- Tutor Availability[cite: 20] -->
        <h2>Set Weekday Availability</h2>
        <form action="php/tutor_process.php" method="POST">
            <label>Day of Week:</label>
            <select name="day_of_week" required>
                <option value="Monday">Monday</option>
                <option value="Tuesday">Tuesday</option>
                <option value="Wednesday">Wednesday</option>
                <option value="Thursday">Thursday</option>
                <option value="Friday">Friday</option>
            </select>
            <label>Start Time:</label>
            <input type="time" name="start_time" required>
            <label>End Time:</label>
            <input type="time" name="end_time" required>
            <button type="submit" name="set_availability">Save Availability</button>
        </form>
    </div>
</body>
</html>